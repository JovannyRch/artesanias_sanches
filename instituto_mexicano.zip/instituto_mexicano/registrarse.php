<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Registro - Instituto México</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            color: #333;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>

<body>
    <div class="container">
        <h2 class="text-center mb-4">Registro de Usuario - Padre de Familia</h2>
        <form action="procesar_registro.php" style=" display: flex; flex-direction: column; align-items: center; justify-content: center;" method="POST">


            <div class="row">
                <div class="row col-sm-12 col-md-6 col-lg-4 mb-4 ">
                    <label class="form-label" for="idUsuario">IDUsuario:</label><br>
                    <input class="form-control" type="text" name="idUsuario" required>

                    <div class="valid-tooltip">
                        Please choose a unique and valid username.
                    </div>

                </div>


                <div class="row col-sm-12 col-md-6 col-lg-4 mb-4">
                    <label class="form-label" for="nombre">Nombre:</label><br>
                    <input class="form-control" type="text" id="nombre" name="nombre" required><br>
                </div>

                <div class="row col-sm-12 col-md-6 col-lg-4 mb-4">
                    <label class="form-label" for="apellidoPaterno">Apellido Paterno:</label><br>
                    <input class="form-control" type="text" id="apellidoPaterno" name="apellidoPaterno" required><br>
                </div>

                <div class="row col-sm-12 col-md-6 col-lg-4 mb-4">
                    <label class="form-label" for="apellidoMaterno">Apellido Materno:</label><br>
                    <input class="form-control" type="text" id="apellidoMaterno" name="apellidoMaterno"><br>
                </div>

                <div class="row col-sm-12 col-md-6 col-lg-4 mb-4">
                    <label class="form-label" for="edad">Edad:</label><br>
                    <input class="form-control" type="number" id="edad" name="edad"><br>
                </div>

                <div class="row col-sm-12 col-md-6 col-lg-4 mb-4">
                    <label class="form-label" for="sexo">Sexo:</label><br>
                    <select class="form-select" id="sexo" name="sexo">
                        <option value="M">Masculino</option>
                        <option value="F">Femenino</option>
                    </select><br>
                </div>

                <div class="row col-sm-12 col-md-6 col-lg-4 mb-4">
                    <label class="form-label" for="email">Email:</label><br>
                    <input class="form-control" type="email" id="email" name="email" required><br>
                </div>

                <div class="row col-sm-12 col-md-6 col-lg-4 mb-4">
                    <label class="form-label" for="password">Contraseña:</label><br>
                    <input class="form-control" type="password" id="password" name="password" required><br>
                </div>

                <div class="row col-sm-12 col-md-6 col-lg-4 mb-4">
                    <label class="form-label" for="confirm_password">Confirmar Contraseña:</label><br>
                    <input class="form-control" type="password" id="confirm_password" name="confirm_password" required>
                </div>
            </div>

            <input class="form-control" type="hidden" name="tipoUsuario" value="PF">
            <br>
            <input class="btn btn-success" type="submit" value="Registrarse">
            <br>
            <div style="display: flex; gap: 4px; ">
                <a href="iniciar_sesion.php" class="btn btn-primary">Iniciar sesión</a>

                <a href="index.php" class="btn btn-secondary">Regresar</a>
            </div>
        </form>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>

</html>