<!-- 
  
<link rel="icon" type="image/x-icon" href="assets/img/favicon.ico"/>
-->

<link rel="stylesheet" href="assets/css/bootstrap.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/ionicons.css">
<link rel="stylesheet" href="assets/css/admin-lte.css">
<link rel="stylesheet" href="assets/css/app.css">

<link rel="stylesheet" href="assets/css/skin-default.css">

<style>
        .content-wrapper {
          background: #fff;
        }
	</style>

<style>
.content-wrapper, .right-side {
	background-color: #fff;
}
</style>

<style>
    .contenido {
      margin: 0;
      padding: 0;
      font-family: 'Roboto', sans-serif;
      text-align: center;
    }
    label.sms{
      margin-top: 2rem;
    }
  </style>
  <script src="assets/js/jquery.js"></script>
  <script src="assets/js/vue.js"></script>