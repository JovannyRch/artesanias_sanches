  
    <footer style="margin-top: 5%"> 
        <div class="footer-copyright">
          
        </div>
        <div class="row"  style="text-align: right">
            <div class="col-12">
                <ul class="address " style="margin-right: 2%" >
               
                    <li><i class="fa fa-map-marker fa-lg "></i> Paletería y Nevería "Peñaloza" <br>
                    Santiaguito Maxdá, Edo. de México</li>
                    <li> Av. Leopoldo Velasco Mercado 19 <br>
                    Barrio Tercero</li>
                    <li><i class="fa fa-phone"></i>Tels.: 7121735257  </li>
                </ul>
            </div>


        </div>
    </footer>
